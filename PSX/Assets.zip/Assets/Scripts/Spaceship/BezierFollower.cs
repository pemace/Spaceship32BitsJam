using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class BezierFollower : MonoBehaviour
{
    public BezierComponent bezier=null;
    private Spaceship ship=null;
    float t=0;
    // Start is called before the first frame update
    void Start()
    {
        ship=GetComponent<Spaceship>();
        if(bezier!=null)
        {
            transform.position=bezier.get(0);
        }
    }

    // Update is called once per frame
    void FixedUpdate()
    {
        if(ship==null || bezier==null)
            return;
        if(t>1)
            t-=1;
        else if(t<0)
            t=0;
        Vector3 position=bezier.get(t);

        Vector3 derivative=bezier.getDerivative(t);

        float derivativeMagnitude=derivative.magnitude;
        if(Mathf.Approximately(derivativeMagnitude,0))
            return;

        Vector3 relative=position-transform.position;

        Vector3 projected=derivative-Vector3.Dot(derivative,transform.up)*transform.up;
        
        Vector4 delta=new Vector4(
            Vector3.SignedAngle(transform.forward,derivative,transform.right),
            Vector3.SignedAngle(transform.forward,projected,transform.up),
            Vector3.SignedAngle(derivative,transform.up,transform.forward),
            Vector3.Dot(transform.forward,relative)+Vector3.Dot(transform.forward,derivative)
        );
        for(int i=0;i<3;i++)
        {
            float plus360=delta[i]+360;
            float minus360=delta[i]-360;
            float equal=delta[i];

            float absplus360=Mathf.Abs(plus360);
            float absminus360=Mathf.Abs(minus360);
            float absEqual=Mathf.Abs(equal);

            if(absplus360<absEqual && absplus360<absminus360)
                delta[i]=plus360;
            else if(absminus360<absplus360 && absminus360<absEqual)
                delta[i]=minus360;
        }

        for(int i=0;i<4;i++)
            delta[i]/=ship.power[1][i];
        
        float ratio=Mathf.Max(Mathf.Abs(delta.x),Mathf.Abs(delta.y),Mathf.Abs(delta.z),Mathf.Abs(delta.w));

        print(delta);

        if(ratio>=-1 && ratio<=1)
        {
            ship.shipCommand=delta;
            t+=delta.w/derivativeMagnitude;
        }
        else
        {
            ship.shipCommand=delta/=ratio;
            t+=delta.w/ratio/derivativeMagnitude;
        }
    }
}
